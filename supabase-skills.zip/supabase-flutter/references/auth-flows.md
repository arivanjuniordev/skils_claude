# Auth Flows — Supabase Flutter

## Email + Senha

```dart
// Cadastro
await supabase.auth.signUp(
  email: email,
  password: password,
  data: {'display_name': name}, // salvo em raw_user_meta_data
);

// Login
await supabase.auth.signInWithPassword(email: email, password: password);

// Logout
await supabase.auth.signOut();

// Atualizar senha
await supabase.auth.updateUser(UserAttributes(password: newPassword));
```

## Magic Link (link por email)

```dart
await supabase.auth.signInWithOtp(
  email: email,
  emailRedirectTo: 'io.supabase.myapp://login-callback',
);
// Usuário clica no link → app abre via deep link → sessão criada automaticamente
```

## OTP por SMS

```dart
// Enviar código
await supabase.auth.signInWithOtp(phone: '+5511999999999');

// Verificar código
await supabase.auth.verifyOTP(
  phone: '+5511999999999',
  token: '123456',
  type: OtpType.sms,
);
```

## OAuth (Google, Apple, GitHub...)

```dart
// Abre navegador externo
await supabase.auth.signInWithOAuth(
  OAuthProvider.google,
  redirectTo: 'io.supabase.myapp://login-callback',
);
```

### Configurar deep link no Android
```xml
<!-- android/app/src/main/AndroidManifest.xml -->
<intent-filter>
  <action android:name="android.intent.action.VIEW" />
  <category android:name="android.intent.category.DEFAULT" />
  <category android:name="android.intent.category.BROWSABLE" />
  <data android:scheme="io.supabase.myapp" android:host="login-callback" />
</intent-filter>
```

### Configurar deep link no iOS
```xml
<!-- ios/Runner/Info.plist -->
<key>CFBundleURLTypes</key>
<array>
  <dict>
    <key>CFBundleURLSchemes</key>
    <array>
      <string>io.supabase.myapp</string>
    </array>
  </dict>
</array>
```

## Reset de Senha

```dart
// 1. Enviar email de reset
await supabase.auth.resetPasswordForEmail(
  email,
  redirectTo: 'io.supabase.myapp://reset-callback',
);

// 2. Usuário clica no link → app abre com token na URL
// 3. Capturar novo evento de auth no stream:
supabase.auth.onAuthStateChange.listen((data) {
  if (data.event == AuthChangeEvent.passwordRecovery) {
    // Navegar para tela de nova senha
  }
});

// 4. Salvar nova senha
await supabase.auth.updateUser(UserAttributes(password: newPassword));
```

## MFA (Autenticação em dois fatores)

```dart
// Enrolar TOTP
final response = await supabase.auth.mfa.enroll(
  factorType: FactorType.totp,
  issuer: 'MeuApp',
);
final qrCode = response.totp.qrCode; // exibir para o usuário escanear

// Verificar e ativar
await supabase.auth.mfa.challengeAndVerify(
  factorId: response.id,
  code: totpCode, // código do autenticador
);

// Verificar em cada login (se MFA obrigatório)
final factors = await supabase.auth.mfa.listFactors();
if (factors.totp.isNotEmpty) {
  final challenge = await supabase.auth.mfa.challenge(factorId: factors.totp.first.id);
  await supabase.auth.mfa.verify(factorId: factors.totp.first.id, challengeId: challenge.id, code: code);
}
```

## Perfil do usuário

```dart
// Dados do usuário autenticado
final user = supabase.auth.currentUser;
final metadata = user?.userMetadata; // raw_user_meta_data

// Atualizar metadados
await supabase.auth.updateUser(
  UserAttributes(data: {'display_name': 'Novo Nome'}),
);

// Tabela profiles sincronizada com trigger
// (crie um trigger no banco para inserir em profiles quando usuário é criado)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO public.profiles(id, email, display_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'display_name');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
```
