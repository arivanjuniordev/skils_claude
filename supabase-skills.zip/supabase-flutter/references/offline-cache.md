# Offline Cache + Sincronização — Flutter + Supabase

## Setup sqflite

```yaml
dependencies:
  sqflite: ^2.3.0
  path: ^1.8.0
```

```dart
// lib/core/local_database.dart
class LocalDatabase {
  static Database? _db;

  static Future<Database> get instance async {
    _db ??= await _open();
    return _db!;
  }

  static Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'app_cache.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE orders (
            id TEXT PRIMARY KEY,
            total REAL NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            synced_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE INDEX idx_orders_created ON orders(created_at DESC)
        ''');
      },
    );
  }
}
```

## Repository com Cache Local

```dart
class OrdersRepository {
  final SupabaseClient _supabase;
  final Database _db;

  OrdersRepository(this._supabase, this._db);

  // Lê cache imediatamente, sincroniza em background
  Future<List<Order>> getOrders(String userId) async {
    final cached = await _getCached(userId);

    // Dispara sync sem aguardar
    _syncFromServer(userId).ignore();

    return cached;
  }

  Future<List<Order>> _getCached(String userId) async {
    final rows = await _db.query(
      'orders',
      orderBy: 'created_at DESC',
      limit: 50,
    );
    return rows.map(Order.fromMap).toList();
  }

  Future<void> _syncFromServer(String userId) async {
    try {
      final remote = await _supabase
          .from('orders')
          .select('id, total, status, created_at')
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .limit(100);

      final db = await LocalDatabase.instance;
      final batch = db.batch();
      final now = DateTime.now().toIso8601String();

      for (final item in remote as List) {
        batch.insert(
          'orders',
          {...item as Map<String, dynamic>, 'synced_at': now},
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      await batch.commit(noResult: true);
    } on SocketException {
      // offline — cache continua válido, silently ignore
    }
  }

  // Cria localmente + enfileira sync
  Future<Order> createOrder(Map<String, dynamic> data, String userId) async {
    final tempId = 'local_${DateTime.now().millisecondsSinceEpoch}';
    final localOrder = {
      ...data,
      'id': tempId,
      'created_at': DateTime.now().toIso8601String(),
      'synced_at': '',
    };

    // Salva local primeiro (UI responde imediatamente)
    await _db.insert('orders', localOrder);

    try {
      // Tenta enviar para o servidor
      final response = await _supabase
          .from('orders')
          .insert({...data, 'user_id': userId})
          .select()
          .single();

      // Substitui o registro local pelo real
      await _db.delete('orders', where: 'id = ?', whereArgs: [tempId]);
      await _db.insert('orders', {
        ...response as Map<String, dynamic>,
        'synced_at': DateTime.now().toIso8601String(),
      });

      return Order.fromJson(response);
    } catch (_) {
      // Offline — mantém local com tempId para sync posterior
      return Order.fromMap(localOrder);
    }
  }
}
```

## Fila de Sincronização Pendente

```dart
// Para operações que falharam offline e precisam ser reenviadas
class SyncQueue {
  final Database _db;

  SyncQueue(this._db);

  Future<void> enqueue(String operation, Map<String, dynamic> payload) async {
    await _db.insert('sync_queue', {
      'id': const Uuid().v4(),
      'operation': operation,
      'payload': jsonEncode(payload),
      'created_at': DateTime.now().toIso8601String(),
      'attempts': 0,
    });
  }

  Future<void> flush(SupabaseClient supabase) async {
    final pending = await _db.query(
      'sync_queue',
      orderBy: 'created_at ASC',
      where: 'attempts < 3',
    );

    for (final item in pending) {
      try {
        final op = item['operation'] as String;
        final payload = jsonDecode(item['payload'] as String);

        switch (op) {
          case 'create_order':
            await supabase.from('orders').insert(payload);
          case 'update_status':
            await supabase.from('orders')
                .update({'status': payload['status']})
                .eq('id', payload['id']);
        }

        await _db.delete('sync_queue', where: 'id = ?', whereArgs: [item['id']]);
      } catch (_) {
        await _db.rawUpdate(
          'UPDATE sync_queue SET attempts = attempts + 1 WHERE id = ?',
          [item['id']],
        );
      }
    }
  }
}
```
