# Paginação Avançada — Flutter + Supabase

## Infinite Scroll com ChangeNotifier (agnóstico)

```dart
// Funciona com qualquer gerenciador de estado que consome ChangeNotifier
class PaginatedListController<T> extends ChangeNotifier {
  final Future<List<T>> Function(String? cursor) _fetcher;
  final String? Function(T item) _getCursor;

  PaginatedListController({
    required Future<List<T>> Function(String? cursor) fetcher,
    required String? Function(T item) getCursor,
  })  : _fetcher = fetcher,
        _getCursor = getCursor;

  final List<T> items = [];
  String? _cursor;
  bool hasMore = true;
  bool isLoading = false;
  Object? error;

  Future<void> loadMore() async {
    if (isLoading || !hasMore) return;
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      final results = await _fetcher(_cursor);
      items.addAll(results);
      hasMore = results.length == 20; // assume page size 20
      if (results.isNotEmpty) _cursor = _getCursor(results.last);
    } catch (e) {
      error = e;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> refresh() async {
    items.clear();
    _cursor = null;
    hasMore = true;
    await loadMore();
  }
}

// Instanciar para orders
final ordersController = PaginatedListController<Order>(
  fetcher: (cursor) => ordersRepository.fetchOrders(userId: userId, cursor: cursor),
  getCursor: (order) => order.createdAt.toIso8601String(),
);
```

## Widget de Infinite Scroll

```dart
class InfiniteListView<T> extends StatefulWidget {
  final PaginatedListController<T> controller;
  final Widget Function(T item) itemBuilder;
  final Widget? emptyWidget;

  const InfiniteListView({
    super.key,
    required this.controller,
    required this.itemBuilder,
    this.emptyWidget,
  });

  @override
  State<InfiniteListView<T>> createState() => _InfiniteListViewState<T>();
}

class _InfiniteListViewState<T> extends State<InfiniteListView<T>> {
  late final ScrollController _scroll;

  @override
  void initState() {
    super.initState();
    _scroll = ScrollController()..addListener(_onScroll);
    widget.controller.loadMore();
  }

  void _onScroll() {
    if (_scroll.position.extentAfter < 300) {
      widget.controller.loadMore();
    }
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (context, _) {
        final ctrl = widget.controller;

        if (ctrl.items.isEmpty && ctrl.isLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        if (ctrl.items.isEmpty && ctrl.error != null) {
          return Center(child: Text('Erro: ${ctrl.error}'));
        }

        if (ctrl.items.isEmpty) {
          return widget.emptyWidget ?? const Center(child: Text('Nenhum item'));
        }

        return RefreshIndicator(
          onRefresh: ctrl.refresh,
          child: ListView.builder(
            controller: _scroll,
            itemCount: ctrl.items.length + (ctrl.hasMore ? 1 : 0),
            itemBuilder: (context, index) {
              if (index == ctrl.items.length) {
                return const Padding(
                  padding: EdgeInsets.all(16),
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              return widget.itemBuilder(ctrl.items[index]);
            },
          ),
        );
      },
    );
  }
}
```

## Uso

```dart
InfiniteListView<Order>(
  controller: ordersController,
  itemBuilder: (order) => OrderTile(order: order),
  emptyWidget: const Text('Nenhum pedido ainda'),
)
```

## Paginação com Count Total

```dart
// Quando precisar saber o total de páginas
Future<({List<Order> items, int total})> fetchOrdersWithCount({
  required String userId,
  int page = 0,
  int pageSize = 20,
}) async {
  final from = page * pageSize;
  final to = from + pageSize - 1;

  final response = await supabase
      .from('orders')
      .select('id, total, status, created_at', const FetchOptions(count: CountOption.exact))
      .eq('user_id', userId)
      .order('created_at', ascending: false)
      .range(from, to);

  return (
    items: (response as List).map((e) => Order.fromJson(e)).toList(),
    total: response.count ?? 0,
  );
}
```
