---
name: supabase-flutter
description: >
  Guia completo de integração Supabase com Flutter. Use este skill sempre que o usuário
  mencionar supabase_flutter, integrar Supabase num app Flutter, autenticação com Supabase
  no Flutter, queries Dart com Supabase, Realtime no Flutter, Storage no Flutter, ou
  qualquer dúvida sobre como usar Supabase dentro de um app Flutter. Este skill é agnóstico
  a gerenciador de estado — apresenta padrões que funcionam com qualquer solução (Riverpod,
  Bloc, Provider, setState, etc). Para performance de banco de dados (índices, RLS, queries
  SQL, connection pooling), consulte também o skill `supabase-performance`.
---

# Supabase + Flutter — Guia de Integração

> Este skill cobre **como usar** o Supabase no Flutter.
> Para **performance de banco de dados** (índices, RLS, SQL), consulte o skill `supabase-performance`.

---

## 1. Instalação e Setup

### pubspec.yaml
```yaml
dependencies:
  supabase_flutter: ^2.0.0
  cached_network_image: ^3.3.0   # cache de imagens do Storage
```

### Inicialização — uma vez só no main.dart
```dart
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: const String.fromEnvironment('SUPABASE_URL'),
    anonKey: const String.fromEnvironment('SUPABASE_ANON_KEY'),
    authOptions: const FlutterAuthClientOptions(
      authFlowType: AuthFlowType.pkce, // obrigatório em mobile
    ),
  );

  runApp(const MyApp());
}
```

### Acesso global ao cliente
```dart
// lib/core/supabase_client.dart
// Importe este arquivo em qualquer lugar do app
final supabase = Supabase.instance.client;
```

### Variáveis de ambiente (dart-define)
```bash
# Build / run com variáveis injetadas em tempo de compilação
flutter run \
  --dart-define=SUPABASE_URL=https://xxx.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=sua-anon-key
```

---

## 2. Camada de Dados — Repository Pattern

Use um repositório para isolar o Supabase da UI.
Isso facilita trocar o gerenciador de estado sem reescrever a lógica.

```dart
// lib/data/repositories/orders_repository.dart
class OrdersRepository {
  final SupabaseClient _client;

  OrdersRepository(this._client);

  // Busca com cursor pagination
  Future<List<Order>> fetchOrders({
    required String userId,
    String? cursor,
    int limit = 20,
  }) async {
    var query = _client
        .from('orders')
        .select('id, total, status, created_at')
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(limit);

    if (cursor != null) query = query.lt('created_at', cursor);

    final response = await query;
    return (response as List).map((e) => Order.fromJson(e)).toList();
  }

  // Busca única
  Future<Order> fetchOrder(String id) async {
    final response = await _client
        .from('orders')
        .select('id, total, status, created_at, items:order_items(*)')
        .eq('id', id)
        .single();
    return Order.fromJson(response);
  }

  // Criar
  Future<Order> createOrder(Map<String, dynamic> data) async {
    final response = await _client
        .from('orders')
        .insert(data)
        .select()
        .single();
    return Order.fromJson(response);
  }

  // Atualizar
  Future<void> updateStatus(String id, String status) async {
    await _client
        .from('orders')
        .update({'status': status})
        .eq('id', id);
  }

  // Deletar
  Future<void> deleteOrder(String id) async {
    await _client.from('orders').delete().eq('id', id);
  }

  // Stream (Realtime)
  Stream<List<Order>> watchOrders(String userId) {
    return _client
        .from('orders')
        .stream(primaryKey: ['id'])
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(50)
        .map((list) => list.map(Order.fromJson).toList());
  }
}
```

---

## 3. Modelos Tipados

```dart
// lib/data/models/order.dart
class Order {
  final String id;
  final double total;
  final String status;
  final DateTime createdAt;

  const Order({
    required this.id,
    required this.total,
    required this.status,
    required this.createdAt,
  });

  factory Order.fromJson(Map<String, dynamic> json) => Order(
    id:        json['id']        as String,
    total:     (json['total'] as num).toDouble(),
    status:    json['status']    as String,
    createdAt: DateTime.parse(json['created_at'] as String),
  );

  Map<String, dynamic> toInsertJson() => {
    'total':  total,
    'status': status,
  };

  Order copyWith({String? status}) => Order(
    id:        id,
    total:     total,
    status:    status ?? this.status,
    createdAt: createdAt,
  );
}
```

---

## 4. Autenticação

```dart
// lib/data/repositories/auth_repository.dart
class AuthRepository {
  final SupabaseClient _client;
  AuthRepository(this._client);

  // Expõe o stream de estado — use no seu gerenciador de estado preferido
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;

  User? get currentUser => _client.auth.currentUser;
  Session? get currentSession => _client.auth.currentSession;

  Future<void> signInWithEmail(String email, String password) async {
    await _client.auth.signInWithPassword(email: email, password: password);
  }

  Future<void> signUpWithEmail(String email, String password) async {
    await _client.auth.signUp(email: email, password: password);
  }

  Future<void> signInWithGoogle() async {
    await _client.auth.signInWithOAuth(
      OAuthProvider.google,
      redirectTo: 'io.supabase.myapp://login-callback',
    );
  }

  Future<void> signOut() => _client.auth.signOut();

  Future<void> resetPassword(String email) async {
    await _client.auth.resetPasswordForEmail(email);
  }
}
```

### Roteamento baseado em auth (sem gerenciador de estado)
```dart
// Funciona com qualquer abordagem — apenas escuta o stream
class AppRouter extends StatelessWidget {
  const AppRouter({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const SplashScreen();
        final session = snapshot.data!.session;
        return session != null ? const HomePage() : const LoginPage();
      },
    );
  }
}
```

---

## 5. Realtime

### Postgres Changes (eventos do banco)
```dart
// lib/core/realtime_manager.dart
// Centralize os canais para evitar duplicatas e memory leaks

class RealtimeManager {
  final SupabaseClient _client;
  final Map<String, RealtimeChannel> _channels = {};

  RealtimeManager(this._client);

  void subscribe({
    required String channelId,
    required String table,
    required PostgresChangeFilter filter,
    required void Function(PostgresChangePayload) onEvent,
  }) {
    if (_channels.containsKey(channelId)) return; // já inscrito

    final channel = _client
        .channel(channelId)
        .onPostgresChanges(
          event:    PostgresChangeEvent.all,
          schema:   'public',
          table:    table,
          filter:   filter,
          callback: onEvent,
        )
        .subscribe();

    _channels[channelId] = channel;
  }

  Future<void> unsubscribe(String channelId) async {
    final ch = _channels.remove(channelId);
    if (ch != null) await _client.removeChannel(ch);
  }

  Future<void> unsubscribeAll() async {
    for (final ch in _channels.values) {
      await _client.removeChannel(ch);
    }
    _channels.clear();
  }
}
```

### Uso em StatefulWidget
```dart
class OrdersListener extends StatefulWidget {
  final String userId;
  const OrdersListener({super.key, required this.userId});

  @override
  State<OrdersListener> createState() => _OrdersListenerState();
}

class _OrdersListenerState extends State<OrdersListener> {
  late final RealtimeChannel _channel;

  @override
  void initState() {
    super.initState();
    _channel = supabase
        .channel('orders-${widget.userId}')
        .onPostgresChanges(
          event:  PostgresChangeEvent.all,
          schema: 'public',
          table:  'orders',
          filter: PostgresChangeFilter(
            type:   PostgresChangeFilterType.eq,
            column: 'user_id',
            value:  widget.userId,
          ),
          callback: _handleEvent,
        )
        .subscribe();
  }

  void _handleEvent(PostgresChangePayload payload) {
    // Integre com seu gerenciador de estado aqui
    // Ex: context.read<OrdersBloc>().add(OrderChanged(payload))
    // Ex: ref.read(ordersProvider.notifier).handleChange(payload)
    // Ex: setState(() => _applyChange(payload))
  }

  @override
  void dispose() {
    supabase.removeChannel(_channel); // SEMPRE limpe no dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child; // passthrough
}
```

### Broadcast (mensagens entre clientes)
```dart
// Enviar
await supabase
    .channel('room-123')
    .sendBroadcastMessage(event: 'cursor', payload: {'x': 100, 'y': 200});

// Receber
supabase
    .channel('room-123')
    .onBroadcast(
      event: 'cursor',
      callback: (payload) => print(payload),
    )
    .subscribe();
```

---

## 6. Storage

```dart
// lib/data/repositories/storage_repository.dart
class StorageRepository {
  final SupabaseClient _client;
  StorageRepository(this._client);

  // URL pública
  String publicUrl(String bucket, String path) =>
      _client.storage.from(bucket).getPublicUrl(path);

  // URL com resize (processa na origem — economiza banda)
  String resizedUrl(String bucket, String path, {int width = 300}) =>
      _client.storage.from(bucket).getPublicUrl(
        path,
        transform: TransformOptions(width: width, height: width, resize: ResizeType.cover),
      );

  // Upload de arquivo
  Future<String> upload({
    required String bucket,
    required String path,
    required File file,
    bool upsert = true,
  }) async {
    await _client.storage.from(bucket).upload(
      path,
      file,
      fileOptions: FileOptions(upsert: upsert),
    );
    return publicUrl(bucket, path);
  }

  // Upload de bytes (útil para imagens cropadas em memória)
  Future<String> uploadBytes({
    required String bucket,
    required String path,
    required Uint8List bytes,
    required String mimeType,
    bool upsert = true,
  }) async {
    await _client.storage.from(bucket).uploadBinary(
      path,
      bytes,
      fileOptions: FileOptions(contentType: mimeType, upsert: upsert),
    );
    return publicUrl(bucket, path);
  }

  // Deletar
  Future<void> delete(String bucket, String path) async {
    await _client.storage.from(bucket).remove([path]);
  }
}
```

### Exibir imagem com cache
```dart
CachedNetworkImage(
  imageUrl: storageRepository.resizedUrl('avatars', user.avatarPath, width: 200),
  placeholder:  (context, url) => const CircularProgressIndicator(),
  errorWidget:  (context, url, error) => const Icon(Icons.person),
  memCacheWidth: 200,
)
```

---

## 7. Funções RPC

```dart
// Prefira RPC para lógica complexa ou agregações — evita múltiplas queries
Future<Map<String, dynamic>> getUserDashboard(String userId) async {
  final response = await supabase.rpc(
    'get_user_dashboard',
    params: {'p_user_id': userId},
  );
  return response as Map<String, dynamic>;
}

// RPC que retorna lista
Future<List<Map<String, dynamic>>> searchProducts(String term) async {
  final response = await supabase.rpc(
    'search_products',
    params: {'search_term': term},
  );
  return (response as List).cast<Map<String, dynamic>>();
}
```

---

## 8. Tratamento de Erros

```dart
// lib/core/supabase_errors.dart

// Extensão para mensagens amigáveis
extension PostgrestErrorMessage on PostgrestException {
  String get userMessage {
    switch (code) {
      case '23505':   return 'Este registro já existe.';
      case '23503':   return 'Referência inválida.';
      case '42501':   return 'Sem permissão para esta ação.';
      case 'PGRST116': return 'Nenhum resultado encontrado.';
      default:        return 'Erro inesperado. Tente novamente.';
    }
  }
}

// Wrapper reutilizável
Future<T> supabaseCall<T>(Future<T> Function() call) async {
  try {
    return await call();
  } on PostgrestException catch (e) {
    throw AppException(e.userMessage, code: e.code);
  } on AuthException catch (e) {
    throw AppException(e.message);
  } on StorageException catch (e) {
    throw AppException('Erro no storage: ${e.message}');
  } on SocketException {
    throw AppException('Sem conexão com a internet.');
  }
}

// Uso
final orders = await supabaseCall(() => ordersRepository.fetchOrders(userId: userId));
```

---

## 9. Geração de Tipos Dart

O CLI do Supabase gera modelos Dart a partir do schema do banco:

```bash
# Instalar CLI
brew install supabase/tap/supabase   # macOS
# ou: npm install -g supabase

# Login
supabase login

# Gerar tipos Dart
supabase gen types dart \
  --project-id seu-project-id \
  > lib/core/database.types.dart
```

Use os tipos gerados nos repositórios para eliminar erros de digitação em nomes de tabelas e colunas.

---

## 10. Checklist de Integração Flutter

- [ ] `Supabase.initialize()` chamado uma única vez no `main()`
- [ ] `authFlowType: AuthFlowType.pkce` configurado
- [ ] Roteamento usando `onAuthStateChange` stream (não `.currentUser`)
- [ ] Repositórios isolam toda chamada ao Supabase da UI
- [ ] `supabase.removeChannel()` no `dispose()` de todo widget com Realtime
- [ ] Filtro `PostgresChangeFilter` em todo canal Realtime
- [ ] Storage usa `TransformOptions` para redimensionar na origem
- [ ] `cached_network_image` para todas as imagens do Storage
- [ ] Tipos Dart gerados via CLI (`supabase gen types dart`)
- [ ] Erros tratados com extensão em `PostgrestException`

---

## Referências

- `references/auth-flows.md` — OAuth, Magic Link, OTP, MFA
- `references/offline-cache.md` — Cache local com sqflite + sincronização
- `references/pagination.md` — Infinite scroll, cursor pagination avançada

**Skill relacionada:** `supabase-performance` — Índices, RLS performático, EXPLAIN ANALYZE, connection pooling
