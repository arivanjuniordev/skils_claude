# Flutter + Supabase — Padrões Avançados

## Offline-First com sqflite

Para apps que precisam funcionar sem internet:

```dart
// Padrão: lê do cache local primeiro, sincroniza em background
class OrdersRepository {
  final SupabaseClient _supabase;
  final Database _db;

  Future<List<Order>> getOrders(String userId) async {
    // 1. Retorna cache imediatamente
    final cached = await _db.query('orders', where: 'user_id = ?', whereArgs: [userId]);
    
    // 2. Busca do Supabase em background
    _syncFromServer(userId);
    
    return cached.map(Order.fromMap).toList();
  }

  Future<void> _syncFromServer(String userId) async {
    try {
      final remote = await _supabase
          .from('orders')
          .select('id, total, status, created_at, updated_at')
          .eq('user_id', userId)
          .order('updated_at', ascending: false)
          .limit(100);

      // Upsert local
      final batch = _db.batch();
      for (final order in remote) {
        batch.insert('orders', order, conflictAlgorithm: ConflictAlgorithm.replace);
      }
      await batch.commit();
    } catch (_) {
      // offline — silently fail, cache continua válido
    }
  }
}
```

## Upload de Arquivos com Progress

```dart
Future<String> uploadFile({
  required File file,
  required String bucket,
  required String path,
  void Function(double progress)? onProgress,
}) async {
  final bytes = await file.readAsBytes();
  final fileExt = file.path.split('.').last;
  final mimeType = 'image/$fileExt';

  await supabase.storage.from(bucket).uploadBinary(
    path,
    bytes,
    fileOptions: FileOptions(contentType: mimeType, upsert: true),
    retryAttempts: 3,
  );

  return supabase.storage.from(bucket).getPublicUrl(path);
}

// Com progresso visual (chunked)
Future<String> uploadWithProgress(File file, String userId) async {
  const chunkSize = 1024 * 1024; // 1MB chunks
  final bytes = await file.readAsBytes();
  final totalChunks = (bytes.length / chunkSize).ceil();
  
  for (int i = 0; i < totalChunks; i++) {
    final start = i * chunkSize;
    final end = min(start + chunkSize, bytes.length);
    final chunk = bytes.sublist(start, end);
    
    // Notifica progresso
    onProgress?.call((i + 1) / totalChunks);
    
    await supabase.storage.from('uploads').uploadBinary(
      '$userId/chunk_$i',
      chunk,
    );
  }
  // Combina chunks via Edge Function se necessário
  return supabase.storage.from('uploads').getPublicUrl('$userId/final');
}
```

## Infinite Scroll / Pagination

```dart
class InfiniteOrdersNotifier extends StateNotifier<AsyncValue<List<Order>>> {
  InfiniteOrdersNotifier() : super(const AsyncValue.loading()) {
    loadMore();
  }

  String? _lastCursor;
  bool _hasMore = true;
  bool _loading = false;

  Future<void> loadMore() async {
    if (_loading || !_hasMore) return;
    _loading = true;

    try {
      final query = supabase
          .from('orders')
          .select('id, total, status, created_at')
          .eq('user_id', supabase.auth.currentUser!.id)
          .order('created_at', ascending: false)
          .limit(20);

      if (_lastCursor != null) {
        query.lt('created_at', _lastCursor!);
      }

      final results = (await query as List).map(Order.fromJson).toList();
      
      _hasMore = results.length == 20;
      if (results.isNotEmpty) _lastCursor = results.last.createdAt.toIso8601String();

      state = AsyncValue.data([
        ...state.value ?? [],
        ...results,
      ]);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    } finally {
      _loading = false;
    }
  }

  Future<void> refresh() async {
    _lastCursor = null;
    _hasMore = true;
    state = const AsyncValue.loading();
    await loadMore();
  }
}

// Provider
final ordersNotifierProvider = StateNotifierProvider<InfiniteOrdersNotifier, AsyncValue<List<Order>>>(
  (ref) => InfiniteOrdersNotifier(),
);

// Widget
class OrdersList extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ordersAsync = ref.watch(ordersNotifierProvider);
    final notifier = ref.read(ordersNotifierProvider.notifier);

    return ordersAsync.when(
      loading: () => const CircularProgressIndicator(),
      error: (e, _) => Text('Erro: $e'),
      data: (orders) => ListView.builder(
        itemCount: orders.length + 1,
        itemBuilder: (context, index) {
          if (index == orders.length) {
            // Trigger carregamento ao chegar no fim
            notifier.loadMore();
            return const CircularProgressIndicator();
          }
          return OrderTile(order: orders[index]);
        },
      ),
    );
  }
}
```

## Gerenciar múltiplos canais Realtime

```dart
class RealtimeManager {
  static final Map<String, RealtimeChannel> _channels = {};

  static void subscribe(String channelId, {
    required String table,
    required String filter,
    required void Function(PostgresChangePayload) onEvent,
  }) {
    // Evita duplicatas
    if (_channels.containsKey(channelId)) return;

    final channel = supabase
        .channel(channelId)
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: table,
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: filter.split('=')[0],
            value: filter.split('=')[1],
          ),
          callback: onEvent,
        )
        .subscribe();

    _channels[channelId] = channel;
  }

  static Future<void> unsubscribe(String channelId) async {
    final channel = _channels.remove(channelId);
    if (channel != null) {
      await supabase.removeChannel(channel);
    }
  }

  static Future<void> unsubscribeAll() async {
    for (final channel in _channels.values) {
      await supabase.removeChannel(channel);
    }
    _channels.clear();
  }
}
```

## Tratamento de erros Supabase

```dart
extension SupabaseErrorHandler on PostgrestException {
  String get userMessage {
    switch (code) {
      case '23505': return 'Registro já existe';
      case '23503': return 'Referência inválida';
      case '42501': return 'Sem permissão para esta ação';
      case 'PGRST116': return 'Nenhum resultado encontrado';
      default: return 'Erro inesperado. Tente novamente.';
    }
  }
}

// Uso
try {
  await supabase.from('orders').insert(order);
} on PostgrestException catch (e) {
  showSnackBar(e.userMessage);
} on SocketException {
  showSnackBar('Sem conexão com a internet');
}
```
