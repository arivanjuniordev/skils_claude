# RLS Patterns — Supabase

## Princípio #1: RLS deve usar índices

Sempre que uma policy faz lookup em outra tabela, essa coluna precisa de índice.
Teste suas policies com `EXPLAIN ANALYZE` para verificar se há Sequential Scans.

---

## Patterns Comuns

### 1. Usuário vê apenas seus próprios dados
```sql
-- Mais simples e mais rápido — coluna user_id indexada
CREATE POLICY "own data" ON items
  FOR ALL USING (user_id = auth.uid());
```

### 2. Dados públicos + privados
```sql
CREATE POLICY "public or owner" ON posts
  FOR SELECT USING (
    is_public = true OR author_id = auth.uid()
  );
```

### 3. Role-based via JWT (sem query ao banco)
```sql
-- Depois de configurar o hook de JWT customizado
CREATE POLICY "admins see all" ON orders
  FOR SELECT USING (
    (auth.jwt() ->> 'user_role') = 'admin'
    OR user_id = auth.uid()
  );
```

### 4. Multi-tenant via JWT claim
```sql
-- Adicione org_id no JWT para evitar subquery
CREATE POLICY "same org" ON projects
  FOR SELECT USING (
    org_id = (auth.jwt() ->> 'org_id')::uuid
  );
```

### 5. Separar políticas por operação (mais granular)
```sql
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone can read" ON comments
  FOR SELECT USING (true);

CREATE POLICY "auth users can insert" ON comments
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "owner can update" ON comments
  FOR UPDATE USING (author_id = auth.uid())
  WITH CHECK (author_id = auth.uid());

CREATE POLICY "owner can delete" ON comments
  FOR DELETE USING (author_id = auth.uid());
```

### 6. Service Role bypassa RLS (para funções backend)
```ts
// Use a service role key em Edge Functions ou backend confiável
const adminClient = createClient(url, process.env.SUPABASE_SERVICE_ROLE_KEY!)
// Service role ignora RLS — use com cuidado, nunca no cliente
```

### 7. SECURITY DEFINER para queries pesadas
```sql
-- Quando a lógica é complexa, encapsule em função
CREATE OR REPLACE FUNCTION get_accessible_projects(p_user_id uuid)
RETURNS SETOF projects
LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT p.* FROM projects p
  INNER JOIN project_members pm ON pm.project_id = p.id
  WHERE pm.user_id = p_user_id
    AND pm.accepted_at IS NOT NULL;
$$;
-- RLS pode ser menos restritiva na tabela quando a função controla acesso
```

---

## Debugar RLS

```sql
-- Simular auth.uid() específico para testar
SET LOCAL role = authenticated;
SET LOCAL request.jwt.claims = '{"sub": "uuid-do-usuario"}';

-- Testar a query como se fosse esse usuário
SELECT * FROM orders LIMIT 5;

-- Ver todas as policies de uma tabela
SELECT policyname, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'orders';
```
