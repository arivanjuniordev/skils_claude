---
name: supabase-performance
description: >
  Guia de alta performance para Supabase em aplicações Flutter/Dart. Use este skill
  sempre que o usuário mencionar Supabase, PostgreSQL com Supabase, banco de dados para
  app Flutter, queries lentas, RLS (Row Level Security), índices, conexão com banco,
  autenticação Supabase, realtime, storage, supabase_flutter, ou qualquer dúvida sobre
  otimização de banco de dados com Supabase. Use também quando o usuário perguntar sobre
  padrões de arquitetura com Supabase, como estruturar tabelas, Riverpod com Supabase, ou
  como evitar problemas de performance em produção. Aplique este skill proativamente em
  qualquer contexto onde banco de dados e performance são críticos em apps Flutter.
---

# Supabase + Flutter — Performance-First Guide

> Foco: cada decisão aqui prioriza **latência baixa, throughput alto e custo reduzido** em produção.

---

## 1. Configuração Inicial (Singleton Obrigatório)

```dart
// main.dart — inicialize UMA única vez
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: const String.fromEnvironment('SUPABASE_URL'),
    anonKey: const String.fromEnvironment('SUPABASE_ANON_KEY'),
    authOptions: const FlutterAuthClientOptions(
      authFlowType: AuthFlowType.pkce, // obrigatório em mobile
    ),
  );

  runApp(const MyApp());
}

// lib/supabase_client.dart — acesso global, nunca recrie
final supabase = Supabase.instance.client;
```

### pubspec.yaml (dependências essenciais)
```yaml
dependencies:
  supabase_flutter: ^2.0.0
  flutter_riverpod: ^2.4.0
  cached_network_image: ^3.3.0
```

---

## 2. Índices — O Maior Ganho de Performance

### Regras de ouro
- Todo campo em `WHERE`, `JOIN ON`, `ORDER BY` → **precisa de índice**
- Colunas de foreign key → **sempre indexe**
- Campos de busca textual → use `GIN` com `pg_trgm`
- Campos de timestamp para paginação → índice `DESC`

```sql
-- Índice padrão (B-tree)
CREATE INDEX CONCURRENTLY idx_orders_user_id ON orders(user_id);
CREATE INDEX CONCURRENTLY idx_orders_created_at ON orders(created_at DESC);

-- Índice composto (ordem importa: coluna mais seletiva primeiro)
CREATE INDEX CONCURRENTLY idx_orders_user_status
  ON orders(user_id, status)
  WHERE deleted_at IS NULL; -- índice parcial reduz tamanho

-- Busca textual com trigram
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX CONCURRENTLY idx_products_name_trgm
  ON products USING GIN(name gin_trgm_ops);

-- JSONB
CREATE INDEX CONCURRENTLY idx_metadata_gin
  ON items USING GIN(metadata jsonb_path_ops);
```

### Verificar índices não usados (rode mensalmente)
```sql
SELECT schemaname, tablename, indexname, idx_scan
FROM pg_stat_user_indexes
WHERE idx_scan = 0 AND indexname NOT LIKE '%pkey%'
ORDER BY pg_relation_size(indexrelid) DESC;
```

---

## 3. Queries Eficientes em Dart

### Selecione apenas o necessário
```dart
// ❌ Ruim — traz todas as colunas
final data = await supabase.from('users').select();

// ✅ Bom — só o necessário
final data = await supabase
    .from('users')
    .select('id, name, email, avatar_url');
```

### Paginação com cursor (mais rápido que offset)
```dart
// ❌ Offset piora com volume — faz scan completo da tabela
final data = await supabase
    .from('posts')
    .select()
    .range(1000, 1020); // lento com muitos dados

// ✅ Cursor-based — usa índice, sempre rápido
Future<List<Map<String, dynamic>>> loadPage(String? lastCursor) async {
  var query = supabase
      .from('posts')
      .select('id, title, created_at')
      .order('created_at', ascending: false)
      .limit(20);

  if (lastCursor != null) {
    query = query.lt('created_at', lastCursor);
  }

  return await query;
}
```

### Joins eficientes (uma só request via PostgREST)
```dart
// Supabase PostgREST resolve relacionamentos em uma chamada
final data = await supabase
    .from('orders')
    .select('''
      id, total, status,
      user:profiles(id, name, email),
      items:order_items(id, quantity, product:products(id, name, price))
    ''')
    .eq('status', 'pending')
    .limit(50);
```

### Batch operations
```dart
// ✅ Upsert em lote — muito mais eficiente que múltiplos inserts
await supabase
    .from('products')
    .upsert(productsMap, onConflict: 'sku');

// ✅ Delete em lote
await supabase
    .from('logs')
    .delete()
    .lt('created_at', cutoffDate.toIso8601String());
```

### Chamada de função RPC (lógica pesada no banco)
```dart
// Prefira RPC para agregações e lógica complexa
final stats = await supabase.rpc('get_user_dashboard', params: {
  'p_user_id': supabase.auth.currentUser!.id,
});
```

---

## 4. Modelos Tipados — Sem Cast Dinâmico

```dart
class Order {
  final String id;
  final double total;
  final String status;
  final DateTime createdAt;

  Order({
    required this.id,
    required this.total,
    required this.status,
    required this.createdAt,
  });

  factory Order.fromJson(Map<String, dynamic> json) => Order(
    id: json['id'] as String,
    total: (json['total'] as num).toDouble(),
    status: json['status'] as String,
    createdAt: DateTime.parse(json['created_at'] as String),
  );

  Map<String, dynamic> toJson() => {
    'total': total,
    'status': status,
  };
}

// Uso seguro
final response = await supabase
    .from('orders')
    .select('id, total, status, created_at')
    .eq('user_id', userId)
    .limit(20);

final orders = (response as List)
    .map((e) => Order.fromJson(e as Map<String, dynamic>))
    .toList();
```

---

## 5. RLS (Row Level Security) com Performance

RLS mal escrito é a **principal causa de lentidão** em apps Supabase.

### Padrão correto de policy
```sql
-- ❌ Lento — subquery executa por linha
CREATE POLICY "users can see own orders" ON orders
  FOR SELECT USING (
    user_id IN (SELECT id FROM profiles WHERE auth_id = auth.uid())
  );

-- ✅ Rápido — comparação direta com coluna indexada
CREATE POLICY "users can see own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

-- ✅ Para roles/permissões — use JWT claims (zero query)
CREATE POLICY "admins can see all" ON orders
  FOR SELECT USING (
    (auth.jwt() ->> 'user_role') = 'admin'
  );
```

### Adicionar role ao JWT (hook no Auth)
```sql
CREATE OR REPLACE FUNCTION public.custom_access_token_hook(event jsonb)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE
  claims jsonb;
  user_role text;
BEGIN
  SELECT role INTO user_role FROM public.profiles
    WHERE id = (event->>'user_id')::uuid;
  claims := event->'claims';
  claims := jsonb_set(claims, '{user_role}', to_jsonb(user_role));
  RETURN jsonb_set(event, '{claims}', claims);
END;
$$;
```

### Security Definer para queries complexas
```sql
CREATE OR REPLACE FUNCTION get_user_dashboard(p_user_id uuid)
RETURNS TABLE(order_count bigint, total_revenue numeric, last_order timestamptz)
LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT
    COUNT(*)        AS order_count,
    SUM(total)      AS total_revenue,
    MAX(created_at) AS last_order
  FROM orders
  WHERE user_id = p_user_id;
$$;
```

---

## 6. Riverpod + Supabase (Cache e Estado)

```dart
// providers/supabase_provider.dart
final supabaseProvider = Provider((ref) => Supabase.instance.client);

// FutureProvider com cache automático e autoDispose
final ordersProvider = FutureProvider.autoDispose.family<List<Order>, String>(
  (ref, userId) async {
    final client = ref.watch(supabaseProvider);
    final response = await client
        .from('orders')
        .select('id, total, status, created_at')
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(20);
    return (response as List).map((e) => Order.fromJson(e)).toList();
  },
);

// StreamProvider para dados em tempo real
final ordersStreamProvider = StreamProvider.autoDispose.family<List<Order>, String>(
  (ref, userId) {
    final client = ref.watch(supabaseProvider);
    return client
        .from('orders')
        .stream(primaryKey: ['id'])
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(20)
        .map((list) => list.map(Order.fromJson).toList());
  },
);

// Notifier com mutation e invalidação
class OrdersNotifier extends AsyncNotifier<List<Order>> {
  @override
  Future<List<Order>> build() async {
    final userId = ref.watch(supabaseProvider).auth.currentUser!.id;
    final response = await ref.watch(supabaseProvider)
        .from('orders')
        .select('id, total, status, created_at')
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(20);
    return (response as List).map((e) => Order.fromJson(e)).toList();
  }

  Future<void> createOrder(Map<String, dynamic> orderData) async {
    await ref.watch(supabaseProvider).from('orders').insert(orderData);
    ref.invalidateSelf(); // recarrega a lista
  }
}
```

---

## 7. Realtime com Performance

```dart
class OrdersPage extends StatefulWidget {
  const OrdersPage({super.key});
  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  late final RealtimeChannel _channel;

  @override
  void initState() {
    super.initState();
    final userId = supabase.auth.currentUser!.id;

    _channel = supabase
        .channel('orders-$userId') // nome único por usuário
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'orders',
          filter: PostgresChangeFilter(   // FILTRO OBRIGATÓRIO em produção
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: userId,
          ),
          callback: (payload) => setState(() => _handleChange(payload)),
        )
        .subscribe();
  }

  @override
  void dispose() {
    supabase.removeChannel(_channel); // CRÍTICO — evita memory leak
    super.dispose();
  }
}
```

---

## 8. Storage com Cache de Imagens

```dart
// URL pública simples
String avatarUrl(String path) =>
    supabase.storage.from('avatars').getPublicUrl(path);

// URL com redimensionamento na origem (reduz banda do app)
String avatarUrlResized(String path, {int width = 200}) =>
    supabase.storage.from('avatars').getPublicUrl(
      path,
      transform: TransformOptions(width: width, height: width),
    );

// Widget com cache em disco
CachedNetworkImage(
  imageUrl: avatarUrlResized(user.avatarPath),
  placeholder: (context, url) => const CircularProgressIndicator(),
  errorWidget: (context, url, error) => const Icon(Icons.person),
  memCacheWidth: 200, // limita memória RAM
)

// Upload com tratamento de erro
Future<String?> uploadAvatar(File file, String userId) async {
  try {
    final ext = file.path.split('.').last;
    final path = '$userId/avatar.$ext';
    await supabase.storage.from('avatars').upload(
      path,
      file,
      fileOptions: const FileOptions(upsert: true),
    );
    return supabase.storage.from('avatars').getPublicUrl(path);
  } on StorageException catch (e) {
    debugPrint('Upload falhou: ${e.message}');
    return null;
  }
}
```

---

## 9. Auth com Escuta de Estado

```dart
// ✅ Use o stream — reage a login/logout/token refresh
// NUNCA use .currentUser diretamente para decidir rotas
class AppRouter extends StatelessWidget {
  const AppRouter({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (context, snapshot) {
        final session = snapshot.data?.session;
        if (session != null) return const HomePage();
        return const LoginPage();
      },
    );
  }
}

// Login com email/senha
Future<void> signIn(String email, String password) async {
  try {
    await supabase.auth.signInWithPassword(email: email, password: password);
  } on AuthException catch (e) {
    throw Exception(e.message);
  }
}

// Logout
Future<void> signOut() => supabase.auth.signOut();
```

---

## 10. Diagnóstico de Performance

### Queries mais lentas (SQL Editor do Supabase)
```sql
SELECT
  round(total_exec_time::numeric, 2) AS total_ms,
  calls,
  round(mean_exec_time::numeric, 2)  AS mean_ms,
  round((100 * total_exec_time / sum(total_exec_time) OVER ())::numeric, 2) AS pct,
  query
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 10;
```

### EXPLAIN ANALYZE — identifica falta de índice
```sql
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT * FROM orders
WHERE user_id = 'uuid-aqui' AND status = 'pending'
ORDER BY created_at DESC LIMIT 20;

-- Procure: "Seq Scan" → precisa de índice
-- Desejável: "Index Scan" ou "Bitmap Index Scan"
```

### Tamanho das tabelas
```sql
SELECT
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname || '.' || tablename)) AS total,
  pg_size_pretty(pg_indexes_size(schemaname || '.' || tablename))        AS indexes
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname || '.' || tablename) DESC;
```

### Debug RLS — simular usuário no SQL Editor
```sql
SET LOCAL role = authenticated;
SET LOCAL request.jwt.claims = '{"sub": "uuid-do-usuario"}';
SELECT * FROM orders LIMIT 5; -- testa como se fosse o usuário
```

---

## 11. Tratamento de Erros

```dart
extension SupabaseErrorHandler on PostgrestException {
  String get userMessage {
    switch (code) {
      case '23505': return 'Registro já existe';
      case '23503': return 'Referência inválida';
      case '42501': return 'Sem permissão para esta ação';
      case 'PGRST116': return 'Nenhum resultado encontrado';
      default:      return 'Erro inesperado. Tente novamente.';
    }
  }
}

// Uso padrão
Future<void> createOrder(Map<String, dynamic> data) async {
  try {
    await supabase.from('orders').insert(data);
  } on PostgrestException catch (e) {
    throw Exception(e.userMessage);
  } on SocketException {
    throw Exception('Sem conexão com a internet');
  }
}
```

---

## 12. Checklist — Antes de ir pra Produção

**Banco de dados:**
- [ ] Todas as foreign keys têm índice
- [ ] Policies de RLS usam comparação direta (`auth.uid() = user_id`)
- [ ] `.select()` sem argumentos eliminado — sempre especifique colunas
- [ ] Paginação com cursor, não `.range(offset, limit)`
- [ ] Realtime com `PostgresChangeFilter` — nunca subscribe sem filtro
- [ ] Rodou `EXPLAIN ANALYZE` nos 5 queries mais usados
- [ ] `pg_stat_statements` habilitado no Dashboard

**Flutter:**
- [ ] `Supabase.initialize()` chamado uma única vez no `main()`
- [ ] `supabase.removeChannel()` no `dispose()` de todo widget com Realtime
- [ ] Todos os modelos têm `fromJson` tipado — sem `dynamic` solto
- [ ] `cached_network_image` para imagens do Storage
- [ ] `authFlowType: AuthFlowType.pkce` habilitado
- [ ] Riverpod com `autoDispose` em todos os providers de dados
- [ ] Storage usa `TransformOptions` para redimensionar imagens na origem

---

## Referências Detalhadas

- `references/schema-patterns.md` — Padrões de schema (multi-tenant, soft delete, auditoria, contadores)
- `references/rls-patterns.md` — Policies RLS para cenários complexos com debug
- `references/flutter-patterns.md` — Offline-first, infinite scroll, upload com progresso, multi-canal Realtime
